import pandas as pd
import json  # Import json to use for dumping the JSON correctly

def generate():
    # Define your locations
    kpis = [
        "Maximum pollutant level 2.5 (µg/m³)",
        "Maximum pollutant level 10 (µg/m³)",
        "Average of 2.5 (µg/m³)",
        "Average of 10 (µg/m³)",
        "Overall quality index (aqi)",
    ]

    # Create a dictionary to hold data for each kpi
    kpi_data = {}

    # Generate data for each location
    for kpi in kpis:
        # Example DataFrame for each location
        data = {
            'Hour': [f"{i}:00" for i in range(24)],
            'value': [20, 21, 22, 19, 18, 25, 27, 30, 29, 28, 26, 24, 22, 21, 20, 19, 18, 15, 12, 10, 15, 20, 25, 30],
            'threshold': 23
        }
        df = pd.DataFrame(data)

        # Prepare JSON data for the current location
        kpi_data[kpi] = {
            "title": kpi,
            "datasets": [
                {
                    "data": df["value"].tolist(),
                    "borderColor": "rgba(54, 162, 235, 1)",
                    "fill": False,  
                    "borderWidth": 1,
                    "tension": 0
                },
            ],
            "scales": {
                "x": {
                    "title": {
                        "display": kpi == kpis[-1],  # Use Python's True (will convert to true in JSON)
                        "text": "Hour of Day"
                    },
                    "ticks": {
                        "display": kpi == kpis[-1], #only display orizontal ticks on the last graph for layout purpose
                        "font": {
                            "size": 10 
                        }
                    }
                },
                "y": {
                    "beginAtZero": True,
                    "title": {
                        "display": True,
                        "text": "Level"
                    },
                    "ticks": {
                        "font": {
                            "size": 10 
                        }
                    }
                }
            },
            "hours": df["Hour"].tolist(),
            "threshold": data["threshold"],  # Add the threshold value here
            "backgroundColor": "rgba(255, 99, 71, 0.7)" if any(df["value"] > df["threshold"].iloc[0]) else "rgba(255, 255, 255, 0.0)"  # Light red if exceeds
        }

    # Prepare the final JSON structure
    json_data = {
        "kpis": kpi_data
    }

    # Convert to JSON string
    json_string = json.dumps(json_data, indent=4)  # Convert Python dictionary to JSON string with indentation

    # Save JSON to a file
    print(json_string)
    with open('/usr/share/nginx/html/plotData/current/kpi/data.json', 'w') as json_file:
        json_file.write(json_string)  # Write the JSON string directly to the file
    print("Generated kpis")

# Call the function to generate the JSON
generate()
